//Enter querySelector Code 
var header = document.querySelector("#header").innerHTML
var linkText = document.querySelector("a").innerHTML
var linkHref = document.querySelector("a")


// NO NEED TO MODIFY BELOW HERE
console.log(`The header is: ${header}`)
console.log(`The first link text is: ${linkText}`)
console.log(`The first link href is: ${linkHref}`)